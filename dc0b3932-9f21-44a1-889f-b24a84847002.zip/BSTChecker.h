#ifndef BSTCHECKER_H
#define BSTCHECKER_H

// Your code here (include additional header files, if needed)
#include "Node.h"

class BSTChecker {
public:
   static Node* CheckBSTValidity(Node* rootNode) {
      // Your code here (remove the placeholder line below)
      return rootNode;
   }
};

#endif